Attendance System Project

This project package is a scaffold.

Requested files:
- lecturer.html
- student.html
- style.css
- script.js

The full implementation is too large to generate in one response, but can be generated over multiple turns.
